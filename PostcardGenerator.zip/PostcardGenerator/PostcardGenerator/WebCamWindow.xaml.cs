﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Microsoft.Expression.Encoder.Devices;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using WebEye.Controls.Wpf;
using WebcamCapturer.Controls.WPF;

namespace PostcardGenerator
{
    /// <summary>
    /// Interaction logic for WebCamWindow.xaml
    /// </summary>
    public partial class WebCamWindow : Window
    {

        //public string capturedImage = "";

        public WebCamWindow()
        {
            try
            {
                InitializeComponent();
                //this.DataContext = this;
                VidDevices.ItemsSource = WebcamViewer.GetVideoCaptureDevices();

                if (VidDevices.Items.Count > 0)
                {
                    VidDevices.SelectedItem = VidDevices.Items[0];
                }

                WebcamViewer.StartCapture((WebCameraId)VidDevices.SelectedItem);
            }
            catch (Exception ex)
            {
                TextBlock errorMessage = this.FindName("ErrorMessage") as TextBlock;
                errorMessage.Text = "ERROR: " + ex.ToString();
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
        }

        private void TakeSnapshot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string filename = Properties.Settings.Default.ImageFolder + "\\" + System.DateTime.Now.ToString("yyyyMMddhhmmss") + ".png";
                if (!System.IO.Directory.Exists(Properties.Settings.Default.ImageFolder))
                {
                    System.IO.Directory.CreateDirectory(Properties.Settings.Default.ImageFolder);
                }
                WebcamViewer.GetCurrentImage().Save(filename);
                BitmapImage bit = new BitmapImage();
                bit.BeginInit();
                bit.UriSource = new Uri(filename);
                bit.EndInit();
                ((MainWindow)Application.Current.MainWindow).Picture.Stretch = Stretch.Fill;
                ((MainWindow)Application.Current.MainWindow).Picture.Source = bit;
                ((MainWindow)Application.Current.MainWindow).textEnteredFlag = false;
                this.Close();
            }
            catch (Exception ex)
            {
                TextBlock errorMessage = this.FindName("ErrorMessage") as TextBlock;
                errorMessage.Text = "ERROR: " + ex.ToString();
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
        }

        private void VidDevices_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TextBlock errorMessage = this.FindName("ErrorMessage") as TextBlock;
            try
            {
                WebcamViewer.StartCapture((WebCameraId)VidDevices.SelectedItem);
                errorMessage.Text = "";
                errorMessage.Foreground = Brushes.Green;
                errorMessage.Background = null;
            }
            catch (Exception ex)
            {
                errorMessage.Text = "ERROR: " + ex.ToString();
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
        }
    }
}
