﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace PostcardGenerator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Flag to determine whether text was entered into the image
        public bool textEnteredFlag { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            textEnteredFlag = false;
        }

        // Implemented whenever the Update Text button is clicked.
        private void UpdateText_Click(object sender, RoutedEventArgs e)
        {
            TextBox updateText = this.FindName("ImageText") as TextBox;
            TextBlock errorMessage = this.FindName("ErrorMessage") as TextBlock;
            if (updateText.Text.Length > 0 && updateText.Text.Length < 31)
            {
                Image myPicture = this.FindName("Picture") as Image;
                if (myPicture.Source == null)
                {
                    errorMessage.Text = "ERROR: Please insert a picture first.";
                    errorMessage.Foreground = Brushes.Red;
                    errorMessage.Background = Brushes.Yellow;
                }
                else
                {
                    // Places text into the image.
                    DrawingVisual dv = new DrawingVisual();
                    using (DrawingContext dc = dv.RenderOpen())
                    {
                        dc.DrawImage(myPicture.Source, new Rect(0, 0, myPicture.Width, myPicture.Height));
                        dc.DrawText(new FormattedText(updateText.Text, System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                            new Typeface("Segoe UI"), 32, Brushes.Black), new Point(0, 0));
                    }
                    DrawingImage di = new DrawingImage(dv.Drawing);
                    myPicture.Source = di;
                    textEnteredFlag = true;

                    // Clears the error message.
                    errorMessage.Text = "";
                    errorMessage.Background = null;
                }
            }
            else if (updateText.Text.Length == 0)
            {
                errorMessage.Text = "ERROR: Image text cannot be empty.";
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
            else
            {
                errorMessage.Text = "ERROR: Maximum character limit of 30 exceeded.";
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
        }

        // Implemented whenever Send Email button is clicked
        private void SendEmail_Click(object sender, RoutedEventArgs e)
        {
            TextBox sendEmail = this.FindName("EmailAddress") as TextBox;
            TextBlock errorMessage = this.FindName("ErrorMessage") as TextBlock;
            Image myPicture = this.FindName("Picture") as Image;
            if (sendEmail.Text.Length == 0)
            {
                errorMessage.Text = "ERROR: Email field cannot be empty.";
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
            else if (myPicture.Source == null)
            {
                errorMessage.Text = "ERROR: No picture has been loaded.";
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
            else if (!textEnteredFlag)
            {
                errorMessage.Text = "ERROR: Please add text to the image before sending it.";
                errorMessage.Foreground = Brushes.Red;
                errorMessage.Background = Brushes.Yellow;
            }
            else
            {
                // Regular expression used to match an email address.
                Regex rx = new Regex(@"\S+\@\S+\.\S+");
                Match match = rx.Match(sendEmail.Text);
                if (match.Success)
                {
                    try
                    {
                        MailMessage mm = new MailMessage();
                        SmtpClient sC = new SmtpClient(Properties.Settings.Default.SmtpClient);

                        // Determine email sender, receiver, and subject
                        mm.From = new MailAddress(Properties.Settings.Default.Email);
                        mm.To.Add(sendEmail.Text);
                        mm.Subject = "Postcard Generator Test";

                        // Put the resulting image in a new bitmap file and save it
                        DrawingVisual dv = new DrawingVisual();
                        using (DrawingContext dc = dv.RenderOpen())
                            dc.DrawImage(myPicture.Source, new Rect(0, 0, myPicture.Width, myPicture.Height));
                        RenderTargetBitmap bitmap = new RenderTargetBitmap((int)myPicture.Width, (int)myPicture.Height, 96, 96, PixelFormats.Pbgra32);
                        bitmap.Render(dv);
                        PngBitmapEncoder enc = new PngBitmapEncoder();
                        enc.Frames.Add(BitmapFrame.Create(bitmap));
                        string filePath = Properties.Settings.Default.ImageFolder + @"\image" + System.DateTime.Now.ToString("yyyyMMddhhmmss") + ".png";
                        if (!System.IO.Directory.Exists(Properties.Settings.Default.ImageFolder))
                        {
                            System.IO.Directory.CreateDirectory(Properties.Settings.Default.ImageFolder);
                        }
                        using (FileStream stream = new FileStream(filePath, FileMode.Create))
                            enc.Save(stream);

                        // Add the resulting image as an attachment
                        mm.Attachments.Add(new Attachment(filePath));

                        // Determine credentials (settings file uses an encrypted password)
                        sC.Port = Properties.Settings.Default.SmtpPort;
                        sC.UseDefaultCredentials = false;
                        byte[] base64 = System.Convert.FromBase64String(Properties.Settings.Default.EncryptedPassword);
                        sC.Credentials = new System.Net.NetworkCredential(Properties.Settings.Default.Email, System.Text.Encoding.UTF8.GetString(base64));
                        sC.EnableSsl = true;

                        // Send the email
                        sC.Send(mm);
                        errorMessage.Text = "Email sent to " + sendEmail.Text;
                        errorMessage.Foreground = Brushes.Green;
                        errorMessage.Background = null;
                    }
                    catch (Exception ex)
                    {
                        errorMessage.Text = "ERROR: " + ex.ToString();
                        errorMessage.Foreground = Brushes.Red;
                        errorMessage.Background = Brushes.Yellow;
                    }
                }
                else
                {
                    errorMessage.Text = "ERROR: Please enter a valid email address.";
                    errorMessage.Foreground = Brushes.Red;
                    errorMessage.Background = Brushes.Yellow;
                }
            }
        }

        // Select file from the open file dialog
        private void SelectFile_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            // Make only image files available
            ofd.Filter = "Image files (*.jpg, *.jpeg, *.jpe, *.jfif, *.png, *.bmp)|*.jpg; *.jpeg; *.jpe; *.jfif; *.png; *.bmp";
            System.Windows.Forms.DialogResult result = ofd.ShowDialog();
            Image myPicture = this.FindName("Picture") as Image;
            BitmapImage bit = new BitmapImage();
            if (result == System.Windows.Forms.DialogResult.OK)
            {
                // Draw image onto canvas
                bit.BeginInit();
                bit.UriSource = new Uri(ofd.FileName);
                bit.EndInit();
                myPicture.Stretch = Stretch.Fill;
                myPicture.Source = bit;
                textEnteredFlag = false;
            }
        }

        // Opens a separate window to show a WebCam
        private void WebCam_Click(object sender, RoutedEventArgs e)
        {
            WebCamWindow wcw = new WebCamWindow();
            wcw.Show();
        }

        // Implemented when a Picture is dropped onto the canvas
        private void Picture_Drop(object sender, DragEventArgs e)
        {
            Image myPicture = (Image)sender;
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // Ensure only image files are placed.
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                Regex rx = new Regex(@".*(.jpg|.jpeg|.jpe|.jfif|.png|.bmp)$");
                Match match = rx.Match(files[0]);
                if (match.Success)
                {
                    // Redraws the canvas with a new image
                    BitmapImage bit = new BitmapImage();
                    bit.BeginInit();
                    bit.UriSource = new Uri(files[0]);
                    bit.EndInit();
                    myPicture.Stretch = Stretch.Fill;
                    myPicture.Source = bit;
                    textEnteredFlag = false;
                }
            }
        }
    }
}
